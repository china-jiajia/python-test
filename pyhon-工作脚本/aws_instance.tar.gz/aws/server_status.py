#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author: jiajiatao-20180517

import time
import os,sys
import commands
import datetime
import paramiko



def battle_check():
    hostname = '10.1.6.163'
    port = 22
    username = 'root'
    pkey = '/root/.ssh/id_rsa'
    key = paramiko.RSAKey.from_private_key_file(pkey)
    s = paramiko.SSHClient()
    s.load_system_host_keys()
    s.connect(hostname,port,username,pkey=key,timeout=5)

    while True:
        (status,output) = commands.getstatusoutput("ps -ef |grep 'battle_server'|grep -v grep |awk '{print $2}'")
        time.sleep(300)
        print status,output
        if output == '':
            print('Battle Server Is Stopped!')
            stdin,stdout,stderr = s.exec_command('/usr/bin/python /infra/battle/boto3-aws-stop.py')
            break;


if __name__ == "__main__":
    battle_check()



