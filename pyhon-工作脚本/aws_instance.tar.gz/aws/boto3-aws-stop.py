#!/usr/bin/env python 
# -*- coding: utf-8 -*-

import boto3
from boto3.session import Session
import smtplib
from email.mime.text import MIMEText
import time
import datetime


otime = str(datetime.datetime.now())
ltime = otime.split('.')
ntime = ltime[0]
ec2 = boto3.client('ec2')
InstanceId = 'i-018b002d560b81b94'

def ec2_stop():
    response = ec2.stop_instances(
        InstanceIds=[InstanceId]
    )

def ec2_check():
    ec2 = boto3.resource('ec2')

    for instance in ec2.instances.all():
		ins_name = instance.id
		state = list(instance.state.values())
		ins_state = state[1]
		if instance.id == 'i-018b002d560b81b94':
			break;
	    	if ins_state == 'running':
			ec2_stop()
    time.sleep(180)
    for instance in ec2.instances.all():
        ins_name = instance.id
        state = list(instance.state.values())
        ins_state = state[1]
        if instance.id == 'i-018b002d560b81b94':
            break;
    print ins_name,ins_state
#    send_mail(ntime,ins_name,ins_state)
    send_to(ntime,ins_name,ins_state)


def send_mail(to_list,ntime,ins_name,ins_state):
     msg_from = 'nagios@em.denachina.com'
     passwd = 'Hwf23.#whgw'
     msg_to = to_list

     subject = "亚马逊云实例状态管理"
     content = ("时间: %s 实例关机操作: OK 实例名: %s 状态: %s" % (ntime,ins_name,ins_state))

     msg = MIMEText(content)
     msg['Subject'] = subject
     msg['From'] = msg_from
     msg['To'] = msg_to

     try:
         s = smtplib.SMTP("smtp.em.denachina.com", 25)
         s.login(msg_from, passwd)
         s.sendmail(msg_from, msg_to, msg.as_string())
         print ("发送成功")
     except smtplib.SMTPException as e:
         print ("发送失败")
     finally:
         s.quit()

def send_to(ntime,ins_name,ins_state):
    mail_list = ["infra_cn@dena.jp","jia.tian@dena.com","526453770@qq.com","jiajia.tao@dena.com"]
    for i in range(0,len(mail_list)):
        send_mail(mail_list[i],ntime,ins_name,ins_state)
    print("发送成成")


if __name__ == "__main__":
        ec2_check()
