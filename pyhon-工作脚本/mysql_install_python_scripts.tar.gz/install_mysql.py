#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import time
import logging
import re




sowfter_file=raw_input("请输入MySL包名: ")
new_port=raw_input("请输入端口号: ")
myfile=raw_input("请输入安装配置文件: ")

print(sowfter_file)
print(new_port)
print(myfile)

old_port='3306'
m_file=sowfter_file.split('.tar.gz')
mysql_dir=m_file[0]
new_dir='/usr/local/mysql'
install_file='/etc/my.cnf'
print(mysql_dir)




def init_log():
    global logger
    fmt_date = '%Y-%m-%d %H:%M:%S.%s'
    fmt_file = '%(lineno)s %(asctime)s  [%(process)d]: %(levelname)s  %(filename)s  %(message)s'

    log_file = 'installmysql.log'
    logger = logging.getLogger('mysqlinstallloging')
    logger.setLevel(logging.INFO)
    file_handler = logging.FileHandler(log_file, mode='a')
    file_handler.setFormatter(logging.Formatter(fmt_file, fmt_date))
    logger.addHandler(file_handler)


#安装yum依赖
def yum_install():
    os.chdir('/mysql')
    yum_install = os.system('yum install -y perl-Module-Install.noarch  libaio libaio-devel')
    if yum_install == 0:
        print ('Yum 依赖包安装成功!')
    else:
        pass

#MySQL tar包解压、软连接、环境变量设置
def tar_env(sowfter_file,mysql_dir,new_dir):
    user_add = os.system('id mysql')
    if user_add == 0:
        print "mysql user exist!"
    else:
        os.system('groupadd mysql')
        os.system('useradd -g mysql -M -s /sbin/nologin mysql')

    time.sleep(5)
    tar_result = os.system('tar xvf %s -C /opt &>/dev/null' % sowfter_file)
    print(tar_result)
    # tar_result = os.system('tar xvf %s -C /opt &>/dev/null' % sys.argv[1])
    if tar_result == 0:
        print "MySQL tar包解压完毕!"
        os.system('ln -s /opt/{0} {1}'.format(mysql_dir,new_dir))
    else:
        print "MySQL Tar 包解压错误!"
        sys.exit(1)

    time.sleep(5)
    os.system('cp /usr/local/mysql/support-files/mysql.server /etc/init.d/mysqld')
    os.system(" echo 'export PATH=$PATH:/usr/local/mysql/bin' >>/etc/profile")
    os.system('source /etc/profile')
    path_source = os.system('mysql --version')
    if path_source == 0:
        print "MySQL Export Path OK!"
    else:
        print "MySQL Export Path Failed!"
        sys.exit(1)


# 设置安装目录和数据目录的权限
def set_dir(new_port):
    data_dir=os.path.exists('/data/mysql%s/data' % new_port)
    if data_dir == 0:
        os.system('mkdir -p /data/mysql%s/{data,logs,tmp}' % new_port)
        os.system('chown -R mysql:mysql /data/mysql%s/' % new_port) 
        os.system('chown -R mysql:mysql /usr/local/mysql')
        os.system('chown -R mysql:mysql /usr/local/mysql/')
    else:
        print('mysql %s data dir exist!' % new_port)

#初始化MySQL5.7.x实例,打印默认密码
def mysql_install(myfile,install_file,old_port,new_port):
    os.system('cp %s  /etc/my.cnf' % myfile)

    lines=open(install_file,'r').readlines()
    flen=len(lines)-1
    for i in range(flen):
        if old_port in lines[i]:
            lines[i]=lines[i].replace(old_port,new_port)
        open(myfile,'w').writelines(lines)

    #初始化实例
    init = os.system('/usr/local/mysql/bin/mysqld --defaults-file=/etc/my.cnf --initialize')
    if init == 0:
        with open('/data/mysql%s/logs/error.log' % new_port) as logj:
            for line in logj:
                if 'root@localhost' in line:
                    m = re.search('(root@localhost:)(.+)',line)
                    if m:
                        passwd = m.group(2)
                        print "password:%s" % passwd



if __name__ == '__main__':
    init_log()
    logger.info(yum_install())
    logger.info(tar_env(sowfter_file,mysql_dir,new_dir))
    logger.info(set_dir(new_port))
    logger.info(mysql_install(myfile,install_file,old_port,new_port))
    print("Please implement alter user user() identified by 'xxx';")



# 调用示例
# python install_mysql.py  mysql-5.7.22-linux-glibc2.12-x86_64.tar.gz(MySQL软件包) 3306(MySQL实例端口号) /mysql/my.cnf(安装MySQL实例使用的配置文件)
